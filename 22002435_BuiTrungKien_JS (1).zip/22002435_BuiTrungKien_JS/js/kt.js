function kiemTraUsername() {
    let regex =/^[a-z0-9_-]{3,16}$/;
    let chuoi=document.getElementById("txtChuoi2").value;
    let kq=regex.test(chuoi);
    if (kq==true) {
        document.getElementById('usn').innerHTML="Nhap dung mau"
    } else {
        document.getElementById('usn').innerHTML="Nhap sai mau"
    }
}

function kiemTraEmail() {
    let regex =/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    let chuoi=document.getElementById("txtChuoi3").value;
    let kq=regex.test(chuoi);
    if (kq==true) {
        document.getElementById('kqktt').innerHTML="Nhap dung mau"
    } else {
        document.getElementById('kqktt').innerHTML="Nhap sai mau"
    }
}
function kiemTraMK() {
    let regex =/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,10}$/;
    let chuoi=document.getElementById("txtChuoi1").value;
    let kq=regex.test(chuoi);
    if (kq==true) {
        document.getElementById('btcq').innerHTML="Nhap dung mau"
    } else {
        document.getElementById('btcq').innerHTML="Nhap sai mau"
    }
}
function kiemTraIP() {
    let regex =/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    let chuoi=document.getElementById("txtChuoi4").value;
    let kq=regex.test(chuoi);
    if (kq==true) {
        document.getElementById('IP').innerHTML="Nhap dung mau"
    } else {
        document.getElementById('IP').innerHTML="Nhap sai mau"
    }

}
function kiemTraHex() {
    let regex =/^#?([a-f0-9]{6}|[a-f0-9]{3})$/i;
    let chuoi=document.getElementById("txtChuoi5").value;
    let kq=regex.test(chuoi);
    if (kq==true) {
        document.getElementById('hex').innerHTML="Nhap dung mau"
    } else {
        document.getElementById('hex').innerHTML="Nhap sai mau"
    }
}

function kiemTraSLug() {
    let regex =/^[a-z0-9-]+$/;
    let chuoi=document.getElementById("txtChuoi6").value;
    let kq=regex.test(chuoi);
    if (kq==true) {
        document.getElementById('slug').innerHTML="Nhap dung mau"
    } else {
        document.getElementById('slug').innerHTML="Nhap sai mau"
    }
}
function kiemTraURL() {
    let regex =/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
    let chuoi=document.getElementById("txtChuoi7").value;
    let kq=regex.test(chuoi);
    if (kq==true) {
        document.getElementById('url').innerHTML="Nhap dung mau"
    } else {
        document.getElementById('url').innerHTML="Nhap sai mau"
    }
}
function kiemTraHTML() {
    let regex =/^<([a-z\d]+)([^<]+)*(?:>(.*)<\/\1>|\s*\/>)$/;
    let chuoi=document.getElementById("txtChuoi8").value;
    let kq=regex.test(chuoi);
    if (kq==true) {
        document.getElementById('html').innerHTML="Nhap dung mau"
    } else {
        document.getElementById('html').innerHTML="Nhap sai mau"
    }
}
function kiemTraDATES() {
    let regex =/^([1-2][0-9]|3[0-1]|0?[1-9])([-\.\/ ])(1[0-2]|0?[1-9])(\2)([\d]{4}|[\d]{2})$/;
    let chuoi=document.getElementById("txtChuoi9").value;
    let kq=regex.test(chuoi);
    if (kq==true) {
        document.getElementById('date').innerHTML="Nhap dung mau"
    } else {
        document.getElementById('date').innerHTML="Nhap sai mau"
    }
}